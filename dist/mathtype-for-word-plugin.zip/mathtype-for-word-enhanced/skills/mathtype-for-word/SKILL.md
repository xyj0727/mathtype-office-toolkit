---
name: mathtype-for-word
description: Create, replace, number, cross-reference, update, inspect, or validate mathematical equations in Microsoft Word DOCX and PowerPoint PPTX using genuine MathType 7 Equation.DSMT4 objects. Use for DOCX or PPTX equation authoring, TeX-to-MathType conversion, consistent IEEE-style mathematical typography, academic Chinese or English prose around formulas, centered displays, MathType Word equation numbers such as (1), the “equation reference goes here” workflow, CJGE (《岩土工程学报》) MathType format (10.5 pt, TNR italic variables, Symbol italic Greek, 式（n）references), or repairs that must avoid Word OMath, captions, numbered lists, images, and fake text equations.
license: MIT
metadata:
  author: Jia-Ming Zhou (Felimet)
  version: 1.2.1
---

# MathType for Word and PowerPoint

Create real MathType equations in DOCX and PPTX, preserving MathType-native Word numbering and references. Treat source Office files as user data: write a new output unless the user explicitly authorizes in-place replacement.

**Default equation format: CJGE** (《岩土工程学报》). Read [cjge-format.md](references/cjge-format.md) before writing a manifest. The render tools apply it automatically; override only when the user names another journal or format.

## Non-negotiable invariants

- Equations are `Equation.DSMT4` inline OLE objects created by MathType Toggle TeX.
- Numbered displays use MathType `MACROBUTTON MTPlaceRef` and `SEQ MTEqn` fields.
- References use `MTCommand_InsertEqnRef`, its `MTReference` placeholder, and the target number's `MTPlaceRef` action. A resolved reference is a `GOTOBUTTON` containing a nested `REF` to a `ZEqnNum...` bookmark.
- The default number format is simple Arabic equation number only: `(1)`, `(2)`, `(3)`, with chapter and section components disabled.
- Apply numbering to new numbers and the whole processed document. Update fields after edits.
- Never substitute Word numbered lists, captions, `SEQ Equation`, OMath, Unicode-only text, images, or manually typed numbers. Use those only as an explicitly accepted, clearly labeled fallback when MathType is unavailable.
- PowerPoint equations are centered, floating `Equation.DSMT4` OLE objects. PowerPoint has no MathType-native equivalent of Word's equation-number/reference fields, so do not imitate them with typed numbers or links.
- Keep each symbol's mathematical role and font style consistent across display equations, inline math, prose, captions, and definitions.
- Equation size and styles come from a MathType preference file (default `config/cjge_equation_preferences.eqp`), applied at file level with MathType's own API (`apply_mathtype_equation_preferences`). Never change MathType's global defaults or the registry to restyle a document.
- Keep Word, PowerPoint, and MathType automation silent: leave application windows hidden, suppress modal alerts, do not steal focus, and do not automate visible UI with mouse, keyboard, `AppActivate`, or `SendKeys`. If a step cannot run silently, stop and report the limitation.

## Terminal selection

- Detect the active terminal and available executables before invoking the bridge.
- Use PowerShell 7 directly when the active host is `pwsh.exe` 7 or later.
- From Bash on Windows, including Git Bash, or from CMD, invoke the same Windows `pwsh.exe` bridge commands. From WSL Bash, invoke Windows `pwsh.exe`; Linux `pwsh` cannot automate Windows Office COM.
- Never run the bridge inside Windows PowerShell 5.1. If 5.1 is active, switch to Git Bash or CMD and invoke Windows `pwsh.exe` there.
- If no supported terminal or no `pwsh.exe` is available, stop and ask the user to install PowerShell 7 using <https://learn.microsoft.com/zh-tw/powershell/scripting/install/microsoft-update-faq?view=powershell-7.6>. Do not silently downgrade the workflow.
- Read [installation-matrix.md](references/installation-matrix.md) for cross-shell commands and agent-specific installation paths.

## Shared output coordination

- Resolve relative output paths against the user's current working directory. Do not default to the plugin repository or create a tool-named output subdirectory.
- Obey an explicit user-supplied input, output, or directory. Never reinterpret an explicit path, and never treat an input path as permission to overwrite it.
- Operate as a complete standalone skill. Do not assume, require, install, or prompt for `endnote-for-word` merely to complete MathType work.
- Prefix retained non-document artifacts with this skill name, for example `mathtype-for-word-manifest.json` or `mathtype-for-word-validation.json`.
- Give every newly generated DOCX or PPTX a descriptive suffix before its extension. Use `-mathtype` when this skill runs alone. Use `-mathtype-endnote`, for example `<source-stem>-mathtype-endnote.docx`, only when `endnote-for-word` is available and the task requires both skills.
- Verify that `endnote-for-word` is available before planning a joint workflow. If it is unavailable, complete only the MathType scope, keep the standalone suffix, report the unperformed EndNote scope, and never claim combined completion.
- When `endnote-for-word` is available and required, plan one shared final DOCX. Do not create separate MathType and EndNote document trees or keep one document per skill. Preserve the original source, let the first skill publish the shared working copy, let the second skill continue on that same copy with explicit overwrite authorization, then validate the final shared document with both skills.
- Keep bridge-owned temporary sibling files temporary. Do not present them as outputs, and remove retained intermediates after the shared document passes both validations.

## Mandatory Word workflow

1. Preserve the input DOCX and choose an explicit output path.
2. Call `probe_mathtype_word`. Stop on a failed prerequisite; report the exact failed check.
3. If the document holds plain-text mathematics (typed formulas such as `σ1f = (σ3 + Δσ3)·Kp`, symbols such as `T_ult`, `φ`, `E50`), call `scan_plain_text_math` with a `candidates_path` instead of writing a detector. Choose the strategy with the user when it is not obvious: `cjge` (default: expressions become MathType, single symbols become Times New Roman italic text with Word subscripts, as CJGE requires) or `all` (everything becomes MathType). Review every candidate in the JSON file: set `action` to `mathtype`, `italic_text` or `skip`, and correct `tex` (for example an index subscript that should be italic). Then call `prepare_mathtype_markers` to write the marked DOCX and a manifest; add display equations, numbers and references to that manifest when the task needs them.
4. Scan the complete document twice. First inventory every equation candidate and later prose reference. Then classify each candidate as `inline`, `display`, or `display_numbered`, and each prose occurrence as `reference`, using [academic-equation-style.md](references/academic-equation-style.md). Decide every identifier, unique marker, TeX, layout, numbered state, reference marker, and target.
5. Create or complete the schema v1 JSON manifest. Read [workflow-and-schema.md](references/workflow-and-schema.md) for the exact contract and examples.
6. For academic prose and mathematical typography, apply [cjge-format.md](references/cjge-format.md) and [academic-equation-style.md](references/academic-equation-style.md). A display equation must be introduced in the preceding prose and followed by a “式中：” paragraph (no indent, items separated by “；”, ending with “。”) defining every symbol, index, superscript, subscript, unit, and physical meaning that is not already unambiguous. Set each display equation's `punctuation` (“，” before 式中, “。” at the end of a sentence), write descriptive subscripts upright (`\mathrm{}`), and write “式” before every `{{EQREF:…}}` marker. Audit the whole document so variables, vectors, matrices, functions, constants, indices, and units retain one consistent style.
7. Call `render_mathtype_word_document`. Do not edit the same DOCX concurrently in Word. It renders the equations in batches of `batch_size` (default 40) in fresh isolated Word sessions with a checkpoint after each batch, then once (unless the manifest opts out) re-typesets them with the CJGE preferences, applies the CJGE table display layout, sets "at least" spacing where an inline equation would be clipped, writes references as 式（n）, and validates. Above about 150 equations pass `background: true` and poll `get_mathtype_render_status` with the same `output_path` instead of waiting on one long call. If a render fails, times out or is interrupted, call it again with the same input, output and manifest: it resumes from the last checkpoint. Use `allow_unresolved_markers` only for an intentional partial render.
8. If equations were added or edited later, call `apply_mathtype_equation_preferences`, `apply_mathtype_repo_layout` and `fix_mathtype_line_spacing` on the result, then `update_mathtype_word_fields`.
9. Call `validate_mathtype_word_document` with the same manifest. It also checks that every equation matches the CJGE preferences (`equation_format`, repeated problems summarised in one line) and warns about inline equations clipped by exact line spacing. A render is incomplete until validation returns `ok: true`.
10. Check every equation twice, in every task (content-authoring and formatting alike): first `validate_mathtype_word_document` (step 9, must return `ok: true`), then render the result and visually inspect each equation. The work is complete only when both checks pass.
11. Report the output path, counts, native number/reference mechanism, validation result, and any limitations.

## Default format: CJGE

Full rules and checklist: [cjge-format.md](references/cjge-format.md).

- **Sizes and styles** — `config/cjge_equation_preferences.eqp`: Full 10.5 pt, sub/superscripts 58 %, Text/Function/Number Times New Roman upright, Variable Times New Roman italic, lower-case Greek Symbol italic, upper-case Greek and Symbol upright, Vector-Matrix Times New Roman bold italic. `apply_mathtype_equation_preferences` re-typesets each equation's MTEF with MathType's API (MathPage.wll `MTXFormSetPrefs` + `MTXFormEqn`), writes MathType's new WMF preview and size, and stores the preferences in the document (`MTPreferences`) so equations the user adds later use them too. No clipboard, no dialogs.
- **Display layout** — `config/cjge_layout_profile.json` (`apply_mathtype_repo_layout`): 1x3 borderless table, equation centred, number `(n)` right-aligned in Times New Roman 10.5 pt, "at least" 15.6 pt lines, zero padding, no space before/after. The rendered tab paragraph is converted in place (`Range.ConvertToTable`), so numbers and references stay MathType-native. The older word-mathtype-mcp profile remains available as `config/repo_format_profile.json`.
- **Punctuation** — per-equation `punctuation` (“，” “。” “；” or ASCII , . ;) is inserted between the equation and its number in 宋体.
- **References** — `reference_brackets: "fullwidth"` (default) renders 式（n）: an inner bookmark `ZEqnNum…_n` on the number's `SEQ MTEqn` field, the nested `REF` points to it, and full-width brackets wrap the `GOTOBUTTON`. Use `"halfwidth"` for MathType's plain `(n)`.
- **Simultaneous equations** — one number for the group: `\left.\begin{array}{l}…\\ …\end{array}\right\}` (a space after `\\`; `aligned` and `\cr` are not supported by MathType's TeX import).
- **Inline line spacing** — CJGE body text uses exactly 15.6 pt lines, which clips taller inline equations; render switches only those paragraphs to "at least" 15.6 pt (`fix_mathtype_line_spacing` does the same on demand).
- **Opt out** — manifest `equation_preferences: "none"` keeps MathType's current defaults; `display_layout: "tab"` keeps MathType's tab layout; `inline_line_spacing: "keep"` leaves line spacing alone; `validate_mathtype_word_document` accepts `equation_preferences: "none"` to skip the format check.

## Body text (non-equation) formatting

- `apply_cjge_body_format` formats page, title, headings, body, lists, captions, tables (three-line) and the reference list from `config/cjge_body_profile.json`. It never touches MathType runs or equation tables. Use it only when the user asks for journal formatting of the whole manuscript; pass `profile_path` for another journal.
- `report_docx_formatting` returns a compact per-role summary (fonts, sizes, spacing, indents, alignment, table borders) and, with `profile_path: "cjge"`, the deviations. Use it instead of reading raw document XML. If the user's own instructions name a different tool for checking non-equation formatting, follow those instructions.

## Mandatory PowerPoint workflow

1. Preserve the input PPTX and choose a distinct output path.
2. Call `probe_mathtype_powerpoint`. Stop and report the exact failed check when `powerpoint_ready` is false.
3. Put each `{{MATH:id}}` marker alone in a top-level text box. PowerPoint does not support inline external objects.
4. Create a presentation schema v1 manifest, apply [academic-equation-style.md](references/academic-equation-style.md), and read [powerpoint-workflow.md](references/powerpoint-workflow.md).
5. Call `render_mathtype_powerpoint_presentation`, then `validate_mathtype_powerpoint_presentation` with the same manifest.
6. Equations are re-typeset with the same CJGE preferences as Word and sized to one uniform math size (the marker text size by default). In every task, check twice: first `validate_mathtype_powerpoint_presentation`, then render every output slide and visually inspect it (equations and overlap). Both checks must pass.
7. Report that the result contains editable floating MathType OLE objects and that Word-style dynamic numbering/references are unavailable in PPTX.

## MCP tools

Use the bundled local MCP server when available:

- `probe_mathtype_word`: read-only prerequisite check.
- `configure_mathtype_word_defaults`: persist the packaged default profile and MathType warning preferences. Invoke only when the user asks to configure defaults or during an explicitly requested installation.
- `render_mathtype_word_document`: marker-driven conversion and reference placement.
- `validate_mathtype_word_document`: read-only structural validation, plus the CJGE equation-format check (`equation_preferences`, default CJGE, `none` to skip).
- `update_mathtype_word_fields`: update number/reference fields after moving, adding, or deleting equations.
- `apply_mathtype_equation_preferences`: re-typeset every equation with a MathType preference file (default CJGE) and store it in the document.
- `apply_mathtype_repo_layout`: table display layout (default CJGE profile), applied in place.
- `scan_plain_text_math`: find plain-text formulas and symbols (body and tables, reference list skipped) and write a reviewable candidates JSON with suggested TeX and actions.
- `prepare_mathtype_markers`: apply reviewed candidates: markers plus manifest for MathType, italic text with subscripts for simple symbols.
- `get_mathtype_render_status`: progress, log tail and result of a batched or background render.
- `fix_mathtype_line_spacing`: switch exactly spaced paragraphs that clip an inline equation to "at least".
- `apply_cjge_body_format`: CJGE layout for everything except equations.
- `report_docx_formatting`: compact formatting summary and profile deviations.
- `probe_mathtype_powerpoint`: verify the desktop PowerPoint and MathType 7 integration.
- `render_mathtype_powerpoint_presentation`: replace marker-only text boxes with centered, editable MathType OLE objects.
- `validate_mathtype_powerpoint_presentation`: verify expected named OLE objects, centering, and resolved markers.

If MCP is unavailable, invoke the same bridge directly from the plugin root:

```powershell
# Resolve these variables from the user's attached or repository files; never reuse a sample path literally.
pwsh.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File scripts\mathtype-word.ps1 -Action probe
pwsh.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File scripts\mathtype-word.ps1 -Action render -InputPath $inputDocx -OutputPath $outputDocx -ManifestPath $manifestJson
pwsh.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File scripts\mathtype-word.ps1 -Action validate -InputPath $outputDocx -ManifestPath $manifestJson
```

For large documents and plain-text formulas without MCP, use the Python helpers from the same root (each prints one JSON line):

```powershell
python scripts\mathtype_scan.py scan $inputDocx --candidates $candidatesJson --strategy cjge
python scripts\mathtype_scan.py prepare $inputDocx $candidatesJson $markedDocx $manifestJson
python scripts\mathtype_batch.py render --input $markedDocx --output $outputDocx --manifest $manifestJson --batch-size 40
python scripts\mathtype_batch.py status --output $outputDocx
```

## Manifest decisions

- Use stable ASCII IDs such as `energy_balance` or `eq_motion_x`.
- Use collision-resistant visible markers such as `{{MATH:eq_motion_x}}` and `{{EQREF:eq_motion_x}}`.
- Each marker must occur exactly once. Never reuse a marker.
- Map `inline` to `layout: "inline", numbered: false`.
- Map `display` to `layout: "display", numbered: false`.
- Map `display_numbered` to `layout: "display", numbered: true`.
- Map each `reference` occurrence to its own unique `references[].marker`; multiple markers may target the same numbered equation.
- Promote a display to `display_numbered` when the full-document scan finds a specific later reference to it.
- Only display equations may set `numbered: true`. Never create a reference to an unnumbered equation.
- Every reference target must exist and be numbered.
- Optional manifest fields: `punctuation` per display equation; top-level `reference_brackets` (`fullwidth` default), `equation_preferences` (path to .eqp, default CJGE, or `none`), `display_layout` (`table` default, or `tab`).
- Keep TeX on one line. Prefer MathType-compatible TeX primitives. Do not depend on document preambles, user macros, packages, `\label`, or `\ref`.
- Escape backslashes correctly in JSON. For example, TeX `\frac{a}{b}` is JSON string `"\\frac{a}{b}"`.

## Numbering and reference policy

The bundled default mirrors the requested Format Equation Numbers configuration:

- Simple Format.
- Chapter Number off.
- Section Number off.
- Equation Number on, Arabic `1,2,3,...`.
- Enclosure on, parentheses.
- Separator off.
- New equation numbers and Whole document.
- Update equation numbers automatically on.
- Warn when inserting first equation number on.
- Warn when inserting equation references off.
- Use format as default for new documents on within this agent workflow.

The bridge temporarily suppresses blocking dialogs during headless automation, restores the user's warning preferences afterward, and normalizes MathType's native field structure to `(n)`. Read [numbering-and-references.md](references/numbering-and-references.md) before diagnosing or manually repairing a field.

## Editing existing documents

- Use markers for deterministic edits. If the document has no markers, create a working copy and insert unique markers at the intended ranges before rendering.
- Never use broad find/replace on TeX fragments or equation text.
- After reordering or deleting numbered equations, call `update_mathtype_word_fields`, then validate again.
- Do not unlink, flatten, or convert the MathType fields or OLE objects.
- Do not overwrite a locked file. Ask the user to close it or select another output path.

## Advanced ribbon operations

The screenshot-level workflow also includes symbol palettes, equation browsing, preferences, whole-document formatting, conversion, export, MathPage, and help. Read [advanced-ribbon-operations.md](references/advanced-ribbon-operations.md) before using any of them. The MCP surface intentionally automates only the deterministic subset; interactive or whole-document commands require explicit scope, a preserved source, and both checks afterwards: the matching `validate_mathtype_*` tool and visual review.

## PowerPoint boundary

- Use desktop **MathType for Windows**, not the Microsoft 365 task-pane add-in.
- Treat every PowerPoint equation as a floating object; there is no inline OLE placement.
- Keep Word, PowerPoint, and MathType hidden. The bridge uses hidden Word conversion and briefly transfers the OLE object through the Windows clipboard without mouse, keyboard, focus, `AppActivate`, or `SendKeys`.
- Do not launch Word for a PPTX job; the direct PowerPoint path must leave the set of `WINWORD` process IDs unchanged.
- Do not promise MathType-native PowerPoint equation numbering or cross-references. Keep those features in Word, or ask the user to accept a clearly labeled static slide annotation.
- Do not rasterize equations. A valid PPTX output retains `Equation.DSMT4` and opens in desktop MathType when edited.

## Validation gates

Treat any of these as a failed deliverable:

- Missing `Equation.DSMT4` objects.
- Any Word built-in `OMath` object when the requested equations must all be MathType.
- A numbered equation without `MACROBUTTON MTPlaceRef`, hidden/current `SEQ MTEqn`, or parentheses.
- A current `MTSec` or `MTChap` component in a number.
- A reference without `GOTOBUTTON`, nested `REF`, or a live `ZEqnNum...` bookmark.
- Remaining `{{MATH:...}}`, `{{EQREF:...}}`, or `equation reference goes here` text (unless the user asked for a partial render).
- Inline equations clipped by exact line spacing (a validation warning; fix it before delivery).
- Non-sequential equation values starting from 1.
- `Error! Reference source not found.`

## Failure handling

- If probe fails, use [troubleshooting.md](references/troubleshooting.md); do not silently fall back.
- If Toggle TeX does not create exactly one `Equation.DSMT4` object, preserve the input, stop, and report the equation ID and TeX.
- If MathType fails to create or resolve `MTReference`, preserve the failed output only for diagnosis and do not present it as complete.
- If the MCP watchdog reports a timeout, record its isolated Word PID and cleanup result, verify the warning preferences were restored, then retry only the smallest fixture once before escalating. The watchdog terminates only the Office process the bridge logged as its own; it never closes Word windows the user opened.
- A batched render that fails keeps its checkpoint: a failed batch is retried once split in half, and calling render again with the same arguments resumes. `get_mathtype_render_status` shows the failing batch and the log tail. Job state lives under `%APPDATA%\MathTypeForWordAgent\jobs`, never beside the user's files.
- If the requested TeX is outside MathType's supported conversion subset, simplify it, split it into supported expressions, or ask for a MathType-authored source equation.
- Word COM is single-user desktop automation. Do not run two render jobs concurrently in the same Windows profile.

## Reference routing

- Manifest design and end-to-end examples: [workflow-and-schema.md](references/workflow-and-schema.md)
- Native field anatomy and Format Equation Numbers behavior: [numbering-and-references.md](references/numbering-and-references.md)
- Academic placement, consistent symbol typography, definitions, units, and TeX/MathML guidance: [academic-equation-style.md](references/academic-equation-style.md)
- Terminal selection plus Claude Code, Claude Desktop, Codex, and ChatGPT Desktop setup: [installation-matrix.md](references/installation-matrix.md)
- Errors, recovery, and fallback boundary: [troubleshooting.md](references/troubleshooting.md)
- MathType ribbon capability matrix and guarded interactive commands: [advanced-ribbon-operations.md](references/advanced-ribbon-operations.md)
- PowerPoint manifest, floating-object workflow, and validation: [powerpoint-workflow.md](references/powerpoint-workflow.md)
